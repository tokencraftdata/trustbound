# TrustBound: payment-epoch completeness artifact

Version 1.0.0 candidate, updated 10 November 2026. Creator: Sandip Nandi,
Independent Researcher. Companion to *TrustBound: A Mechanized Note on
Payment-Epoch Completeness*.

## Goal and outcome

Check the conditional identity-level payment-completeness model and reproduce
its finite evidence diagnostic. The goal is to make the premises for accounting
for all in-scope effects and excluding later effects under earlier authority
explicit and auditable. Trust is placed in a fully mediating payment service,
its durable journal, truthful source terminality and a faithful export (A1–A5).

A successful run produces a reproduction report, **not a certificate that a real
merchant payment epoch is closed**. It neither contacts a processor nor proves
a deployment satisfies A1–A5. No new general closure principle, executable-to-
Lean refinement, monetary composition or stronger trust boundary is claimed.

## Run the paper core

Use Lean **4.19.0**, Python **3.11+** and pytest **9.0.2**. Recorded executions
used Python 3.12.14 on Apple Silicon macOS. The 9 November check installed
pytest and its dependencies in a fresh Python virtual environment, with the
existing Lean compiler. This was the same host, not an independent clean-machine
installation; other platforms have not been tested. Lean's bundled Std is
sufficient. Install dependencies once; the checks themselves need no network,
provider account, payment credentials, SDK or Docker.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/reproduce_core_claim.py \
  --lean /absolute/path/to/lean-4.19.0/bin/lean \
  --output results/my-core-run
```

Replace the Lean path and use a new output directory. **Do not use Python -O**:
the existing checkers use assertions. Expected exit status is zero.

| Output | Expected result |
|---|---|
| `summary.json` | `checks_passed: true`, with input hashes and check counts |
| `admission/`, `provider_contract/` | 14 exported results accepted; eight altered proofs rejected |
| `baseline-tests.xml` | Nine tests passed, no failures, errors or skips |
| `baseline/closure_benchmark.json` | 2,048 diagnostic records match the saved reference |
| Logs and source hashes | The inputs and execution can be inspected |

The 2,048 records reuse 64 distinct public evidence inputs per arm. The labels
`fenced_reconciliation` and `conventional_reconciliation` use the same stricter
rule; `signed_closure` and `witnessed_log` use the same permissive rule. Equal-information agreement is a consistency check, not
an independently implemented baseline or theorem validation. A bypass violates
mediation; truthful but incomplete observations do not establish complete coverage.
Finite counts are not deployment error rates. Eight rejected mutations show
that the supplied proof text depends on those changes, not universal premise
minimality. The 14 exports are not 14 independent security guarantees.

## Run the repaired service and trace checks

The 10 November supplement uses the actual SQLite gate with synthetic provider
observations. It adds claimed-capture provenance checks and persistent conflict
records. A matching command is necessary evidence, not proof of provider execution.

```sh
PYTHONPATH=src .venv/bin/python -m pytest -q \
  tests/test_gate_observation_integrity.py tests/test_stripe_gate.py \
  tests/test_dispatch_crashes.py tests/test_credential_service.py
.venv/bin/python research/service_refinement/check_traces.py \
  --lean /absolute/path/to/lean-4.19.0/bin/lean \
  --output results/my-service-traces
```

Expected: 66 selected tests pass; six executed histories produce 66 projected
transitions accepted by Lean. Five final states instantiate the existing closure
theorem and one remains undrained. Two invalid histories must fail compilation
because no effective right exists. No new general theorem or all-executions
Python/SQLite refinement is established. The Python projection, complete event
capture and source contracts remain trusted. No real provider calls are made.
Details and saved evidence are in `research/service_refinement/`.

## Run the supplementary flight–hotel diagnostic

```sh
.venv/bin/python research/flight_hotel/check_example.py \
  --output results/my-flight-hotel-run.json
```

Use a new output filename. This finite toy check has 18 trace records, 72
prefix records and 120 continuation replays. It finds no new exact-closure
composition counterexample: the observed failures concern commit-time policy
or final trip usability. It makes no provider calls and is not a new Lean
proof. Details and saved output are in `research/flight_hotel/`.

## Evidence and integrity

`evidence/core/` preserves the original selected-core run; `PROVENANCE.json`
records path/hostname substitutions. Some original log hashes intentionally
differ from the exported, redacted logs; use `SHA256SUMS.json` for current package
integrity. Hashes do not independently attest completeness or authorship.
`evidence/historical/` contains explicitly historical, non-sensitive processor
and simulator summaries; this package does not reproduce live/provider tests.
`review/AdmissionSemantics.lean` has two supplementary reviewer examples outside
the 14-export count; their earlier execution records are retained.

The package excludes provider probes, credentials, raw private provider records,
databases, unrelated research, third-party dependencies and conference templates.
The original formal core and its reference results are unchanged. The repaired
service, selected tests and finite trace checker are an additional local supplement.
`HISTORICAL_PACKAGE_NOTES.md` preserves the original package context.

## License and citation

This is an unpublished release candidate. The MIT text below is a proposed
release choice; the author has not approved public release or granted that
license through this preparation step.

The proposed release would place author-owned code and accompanying
documentation under the MIT license in `LICENSE`. No third-party dependency is relicensed or bundled. This software
license does not select a license for the manuscript. `CITATION.cff` identifies
this version; cite the version DOI on the published archive record once issued.
