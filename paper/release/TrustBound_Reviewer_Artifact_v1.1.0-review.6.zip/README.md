# TrustBound reviewer artifact

This package contains a conditional payment model and finite local checks.
Start with [the reviewer guide](docs/REVIEWER_GUIDE.md) for setup, expected
results, scenario descriptions, and the limits of the evidence.

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-reviewer.txt
.venv/bin/python scripts/reproduce_reviewer_artifact.py \
  --lean /absolute/path/to/lean-4.19.0/bin/lean --output results/reviewer-run
```

Use a new output directory. Lean 4.19.0 must be installed separately.
No provider credentials, SDKs, real payments, or network are needed after setup.
The code and documentation are released under the MIT license (see LICENSE).
This package does not imply a DOI or independent review.
